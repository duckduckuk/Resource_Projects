<div id="content" role="main">
    <div class="alert alert-warning">
        <h1 class="text-danger">
            <i class="bi bi-exclamation-triangle-fill"></i> <?php _e('Error', 'b4st'); ?> 404
        </h1>
        <p class="mt-4"><?php _e('Sorry, we can&rsquo;t find what you were looking for.', 'b4st'); ?></p>
    </div>
</div><!-- /#content -->
