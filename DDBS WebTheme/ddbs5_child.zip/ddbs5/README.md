# DDBS5 – WordPress theme

*Version 1.2.0*

------------------

**DDBS5 is a simple WordPress theme using Bootstrap.**

## Base theme
The base theme can be found here: https://github.com/SimonPadbury/b4st which is open source and freely available to redistribute.

## More

This theme is heavily influenced by the BootScout theme with large section of code transplanted. Bootscout is liceneced under the MIT licence which allows sharing provided acknowlegment is made to the original author, in this case xxxxxxxxxx. As such, it is not available to share beyond the realms of this installation.

See LICENCE One (Licence Folder)
See LICENCE Two (Licence Folder)

### Compile scss to css

From the root directory of the repository run `gulp css` and `gulp editor-css`. This will update editor.css, editor.css.map, b4st.css and b4st.css.map files.

Basic setup info for scss here (not my guide): https://github.com/SimonPadbury/b4st/wiki/Customizing-Bootstrap-4-(SCSS)-in-b4st
