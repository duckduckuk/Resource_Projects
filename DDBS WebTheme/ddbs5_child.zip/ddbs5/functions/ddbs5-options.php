<?php

add_action( 'admin_menu', 'theme_options_add_page' );
add_action( 'admin_init', 'theme_options_init' );

/**
 * Init plugin options to white list our options
 */
function theme_options_init(){
	register_setting( 'ddbs5_options', 'ddbs5_theme_options' );
}

/**
 * Load up the menu page
 */
function theme_options_add_page() {
	add_theme_page( __( 'Theme Options', 'ddbs5-theme' ), __( 'Theme Options', 'ddbs5-theme' ), 'edit_theme_options', 'theme_options', 'theme_options_do_page' );
}

/**
 * Create the options page
 */
function theme_options_do_page() {
	global $select_options, $radio_options;

	if ( ! isset( $_REQUEST['settings-updated'] ) )
		$_REQUEST['settings-updated'] = false;

	?>
	<div class="wrap">
		<?php echo "<h2>" . wp_get_theme() . __( ' Theme Options', 'ddbs5-theme' ) . "</h2>"; ?>

		<?php if ( false !== $_REQUEST['settings-updated'] ) : ?>
		<div class="updated fade"><p><strong><?php _e( 'Options saved', 'ddbs5-theme' ); ?></strong></p></div>
		<?php endif; ?>

		<form method="post" action="options.php">
			<?php settings_fields( 'ddbs5_options' ); ?>
			<?php $options = get_option( 'ddbs5_theme_options' ); ?>

			<table class="form-table">
				<tr><th colspan="2"><h2>DDBS5 Theme Setup</h2></th></tr>
				<tr valign="top"><th scope="row">School/Federation Name</th>
					<td>
						<input id="ddbs5_theme_options[content_owner]" class="regular-text" type="text" name="ddbs5_theme_options[content_owner]" value="<?php esc_attr_e( (is_array($options) && array_key_exists('content_owner', $options)) ? $options['content_owner'] : '' ); ?>" />
						<label class="description" for="ddbs5_theme_options[content_owner]"> Enter the content copyright Owner name here."</label>
					</td>
				</tr>
				<tr valign="top"><th scope="row">Contact Information</th>
					<td>
						<input id="ddbs5_theme_options[headteacher_inf]" class="regular-text" type="text" name="ddbs5_theme_options[headteacher_inf]" value="<?php esc_attr_e( (is_array($options) && array_key_exists('headteacher_inf', $options)) ? $options['headteacher_inf'] : '' ); ?>" />
						<label class="description" for="ddbs5_theme_options[headteacher_inf]"> Contact or Headteacher Name</label><br>
						<input id="ddbs5_theme_options[telephone_inf]" class="regular-text" type="text" name="ddbs5_theme_options[telephone_inf]" value="<?php esc_attr_e( (is_array($options) && array_key_exists('telephone_inf', $options)) ? $options['telephone_inf'] : '' ); ?>" />
						<label class="description" for="ddbs5_theme_options[telephone_inf]"> Contact Address</label><br>
						<input id="ddbs5_theme_options[address_inf]" class="regular-text" type="text" name="ddbs5_theme_options[address_inf]" value="<?php esc_attr_e( (is_array($options) && array_key_exists('address_inf', $options)) ? $options['address_inf'] : '' ); ?>" />
						<label class="description" for="ddbs5_theme_options[address_inf]"> Telephone Number and/or Email Address</label>												
					</td>
				</tr>

				<tr valign="top"><th scope="row">Privacy statement</th>
					<td>
						<input id="ddbs5_theme_options[privacy_link]" class="regular-text" type="text" name="ddbs5_theme_options[privacy_link]" value="<?php esc_attr_e( (is_array($options) && array_key_exists('privacy_link', $options)) ? $options['privacy_link'] : '' ); ?>" />
						<label class="description" for="ddbs5_theme_options[privacy_link]"> Insert page link for your Privacy statement</label>
					</td>
				</tr>
				<tr valign="top"><th scope="row">Ofsted Report</th>
					<td>
						<input id="ddbs5_theme_options[terms_link]" class="regular-text" type="text" name="ddbs5_theme_options[terms_link]" value="<?php esc_attr_e( (is_array($options) && array_key_exists('terms_link', $options)) ? $options['terms_link'] : '' ); ?>" />
						<label class="description" for="ddbs5_theme_options[terms_link]"> Insert page link for your Ofsted Report</label>
					</td>
				</tr>
				<tr valign="top"><th scope="row">District / County link</th>
					<td>
						<input id="ddbs5_theme_options[parent_link]" class="regular-text" type="text" name="ddbs5_theme_options[parent_link]" value="<?php esc_attr_e( (is_array($options) && array_key_exists('parent_link', $options)) ? $options['parent_link'] : '' ); ?>" />
						<label class="description" for="ddbs5_theme_options[parent_link]"> Insert link for your district or county site</label>
					</td>
				</tr>
				<tr valign="top"><th scope="row">District / County link text</th>
					<td>
						<input id="ddbs5_theme_options[parent_text]" class="regular-text" type="text" name="ddbs5_theme_options[parent_text]" value="<?php esc_attr_e( (is_array($options) && array_key_exists('parent_text', $options)) ? $options['parent_text'] : '' ); ?>" />
						<label class="description" for="ddbs5_theme_options[parent_text]"> Insert text to be displayed</label>
					</td>
				</tr>

				<tr><th colspan="2"><h2>Quick links</h2></th></tr>
				<tr valign="top"><th scope="row">Ofsted page link</th>
					<td>
						<input id="ddbs5_theme_options[fb_link]" class="regular-text" type="text" name="ddbs5_theme_options[fb_link]" value="<?php esc_attr_e( (is_array($options) && array_key_exists('fb_link', $options)) ? $options['fb_link'] : '' ); ?>" />
						<label class="description" for="ddbs5_theme_options[fb_link]"> Insert your Ofsted report link</label>
					</td>
				</tr>
				<tr valign="top"><th scope="row">SIAMS page link</th>
					<td>
						<input id="ddbs5_theme_options[SIAMS_link]" class="regular-text" type="text" name="ddbs5_theme_options[SIAMS_link]" value="<?php esc_attr_e( (is_array($options) && array_key_exists('SIAMS_link', $options)) ? $options['SIAMS_link'] : '' ); ?>" />
						<label class="description" for="ddbs5_theme_options[SIAMS_link]"> Insert your SIAMS report link here</label>
					</td>
				</tr>
				<tr valign="top"><th scope="row">Parentlink</th>
					<td>
						<input id="ddbs5_theme_options[osm_link]" class="regular-text" type="text" name="ddbs5_theme_options[osm_link]" value="<?php esc_attr_e( (is_array($options) && array_key_exists('osm_link', $options)) ? $options['osm_link'] : '' ); ?>" />
						<label class="description" for="ddbs5_theme_options[osm_link]"> Insert your Parentview link here</label>
					</td>
				</tr>

				<tr><th colspan="2"><h2>Extra</h2></th></tr>
				<tr valign="top"><th scope="row">Show sidebar</th>
					<td>
						<input id="ddbs5_theme_options[sidebar]" type="checkbox" name="ddbs5_theme_options[sidebar]" value="1"<?php checked( 1 == (isset($options['sidebar']) ? $options['sidebar'] : '') ) ?>>Check to enable<br>
					</td>
				</tr>
				<tr valign="top"><th scope="row">Show quick links in navbar</th>
					<td>
						<input id="ddbs5_theme_options[navbarQuickLinks]" type="checkbox" name="ddbs5_theme_options[navbarQuickLinks]" value="1"<?php checked( 1 == (isset($options['navbarQuickLinks']) ? $options['navbarQuickLinks'] : '') ) ?>>Check to enable<br>
					</td>
				</tr>
				<tr valign="top"><th scope="row">Navbar colour</th>
					<td>
						<select id="ddbs5_theme_options[navColour]" name='ddbs5_theme_options[navColour]'>
							<option selected value>Choose...</option>
							<option value='purple' <?php isset($options['navColour']) ? selected( $options['navColour'], 'purple' ) : '' ?>>Purple</option>
							<option value='teal' <?php isset($options['navColour']) ? selected( $options['navColour'], 'teal' ) : '' ?>>Teal</option>
							<option value='red' <?php isset($options['navColour']) ? selected( $options['navColour'], 'red' ) : '' ?>>Red</option>
							<option value='pink' <?php isset($options['navColour']) ? selected( $options['navColour'], 'pink' ) : '' ?>>Pink</option>
							<option value='green' <?php isset($options['navColour']) ? selected( $options['navColour'], 'green' ) : '' ?>>Green</option>
							<option value='navy' <?php isset($options['navColour']) ? selected( $options['navColour'], 'navy' ) : '' ?>>Navy</option>
							<option value='blue' <?php isset($options['navColour']) ? selected( $options['navColour'], 'blue' ) : '' ?>>Blue</option>
							<option value='yellow' <?php isset($options['navColour']) ? selected( $options['navColour'], 'yellow' ) : '' ?>>Yellow</option>
							<option value='white' <?php isset($options['navColour']) ? selected( $options['navColour'], 'white' ) : '' ?>>White</option>
							<option value='black' <?php isset($options['navColour']) ? selected( $options['navColour'], 'black' ) : '' ?>>Black</option>
							<option value='transparent' <?php isset($options['navColour']) ? selected( $options['navColour'], 'transparent' ) : '' ?>>Transparent</option>								
						</select>
					</td>
				</tr>
				<tr valign="top"><th scope="row">Footer colour</th>
					<td>
						<select id="ddbs5_theme_options[footerColour]" name='ddbs5_theme_options[footerColour]'>
							<option selected value>Choose...</option>
							<option value='purple' <?php isset($options['footerColour']) ? selected( $options['footerColour'], 'purple' ) : '' ?>>Purple</option>
							<option value='teal' <?php isset($options['footerColour']) ? selected( $options['footerColour'], 'teal' ) : '' ?>>Teal</option>
							<option value='red' <?php isset($options['footerColour']) ? selected( $options['footerColour'], 'red' ) : '' ?>>Red</option>
							<option value='pink' <?php isset($options['footerColour']) ? selected( $options['footerColour'], 'pink' ) : '' ?>>Pink</option>
							<option value='green' <?php isset($options['footerColour']) ? selected( $options['footerColour'], 'green' ) : '' ?>>Green</option>
							<option value='navy' <?php isset($options['footerColour']) ? selected( $options['footerColour'], 'navy' ) : '' ?>>Navy</option>
							<option value='blue' <?php isset($options['footerColour']) ? selected( $options['footerColour'], 'blue' ) : '' ?>>Blue</option>
							<option value='yellow' <?php isset($options['footerColour']) ? selected( $options['footerColour'], 'yellow' ) : '' ?>>Yellow</option>
							<option value='white' <?php isset($options['footerColour']) ? selected( $options['footerColour'], 'white' ) : '' ?>>White</option>
							<option value='black' <?php isset($options['footerColour']) ? selected( $options['footerColour'], 'black' ) : '' ?>>Black</option>
							<option value='transparent' <?php isset($options['footerColour']) ? selected( $options['footerColour'], 'transparent' ) : '' ?>>Transparent</option>								
						</select>
					</td>
				</tr>
				<tr valign="top"><th scope="row">Masthead colour</th>
					<td>
						<select id="ddbs5_theme_options[mastColour]" name='ddbs5_theme_options[mastColour]'>
							<option selected value>Choose...</option>
							<option value='purple' <?php isset($options['mastColour']) ? selected( $options['mastColour'], 'purple' ) : '' ?>>Purple</option>
							<option value='teal' <?php isset($options['mastColour']) ? selected( $options['mastColour'], 'teal' ) : '' ?>>Teal</option>
							<option value='red' <?php isset($options['mastColour']) ? selected( $options['mastColour'], 'red' ) : '' ?>>Red</option>
							<option value='pink' <?php isset($options['mastColour']) ? selected( $options['mastColour'], 'pink' ) : '' ?>>Pink</option>
							<option value='green' <?php isset($options['mastColour']) ? selected( $options['mastColour'], 'green' ) : '' ?>>Green</option>
							<option value='navy' <?php isset($options['mastColour']) ? selected( $options['mastColour'], 'navy' ) : '' ?>>Navy</option>
							<option value='blue' <?php isset($options['mastColour']) ? selected( $options['mastColour'], 'blue' ) : '' ?>>Blue</option>
							<option value='yellow' <?php isset($options['mastColour']) ? selected( $options['mastColour'], 'yellow' ) : '' ?>>Yellow</option>
							<option value='white' <?php isset($options['mastColour']) ? selected( $options['mastColour'], 'white' ) : '' ?>>White</option>
							<option value='black' <?php isset($options['mastColour']) ? selected( $options['mastColour'], 'black' ) : '' ?>>Black</option>
							<option value='transparent' <?php isset($options['mastColour']) ? selected( $options['mastColour'], 'transparent' ) : '' ?>>Transparent</option>								
						</select>
					</td>
				</tr>				
				<tr valign="top"><th scope="row">Option 1 colour</th>
					<td>
						<select id="ddbs5_theme_options[opt1Colour]" name='ddbs5_theme_options[opt1Colour]'>
							<option selected value>Choose...</option>
							<option value='purple' <?php isset($options['opt1Colour']) ? selected( $options['opt1Colour'], 'purple' ) : '' ?>>Purple</option>
							<option value='teal' <?php isset($options['opt1Colour']) ? selected( $options['opt1Colour'], 'teal' ) : '' ?>>Teal</option>
							<option value='red' <?php isset($options['opt1Colour']) ? selected( $options['opt1Colour'], 'red' ) : '' ?>>Red</option>
							<option value='pink' <?php isset($options['opt1Colour']) ? selected( $options['opt1Colour'], 'pink' ) : '' ?>>Pink</option>
							<option value='green' <?php isset($options['opt1Colour']) ? selected( $options['opt1Colour'], 'green' ) : '' ?>>Green</option>
							<option value='navy' <?php isset($options['opt1Colour']) ? selected( $options['opt1Colour'], 'navy' ) : '' ?>>Navy</option>
							<option value='blue' <?php isset($options['opt1Colour']) ? selected( $options['opt1Colour'], 'blue' ) : '' ?>>Blue</option>
							<option value='yellow' <?php isset($options['opt1Colour']) ? selected( $options['opt1Colour'], 'yellow' ) : '' ?>>Yellow</option>
							<option value='white' <?php isset($options['opt1Colour']) ? selected( $options['opt1Colour'], 'white' ) : '' ?>>White</option>
							<option value='black' <?php isset($options['opt1Colour']) ? selected( $options['opt1Colour'], 'black' ) : '' ?>>Black</option>
							<option value='transparent' <?php isset($options['opt1Colour']) ? selected( $options['opt1Colour'], 'transparent' ) : '' ?>>Transparent</option>							
						</select>
					</td>
				</tr>
				<tr valign="top"><th scope="row">Option 2 colour</th>
					<td>
						<select id="ddbs5_theme_options[opt2Colour]" name='ddbs5_theme_options[opt2Colour]'>
							<option selected value>Choose...</option>
							<option value='purple' <?php isset($options['opt2Colour']) ? selected( $options['opt2Colour'], 'purple' ) : '' ?>>Purple</option>
							<option value='teal' <?php isset($options['opt2Colour']) ? selected( $options['opt2Colour'], 'teal' ) : '' ?>>Teal</option>
							<option value='red' <?php isset($options['opt2Colour']) ? selected( $options['opt2Colour'], 'red' ) : '' ?>>Red</option>
							<option value='pink' <?php isset($options['opt2Colour']) ? selected( $options['opt2Colour'], 'pink' ) : '' ?>>Pink</option>
							<option value='green' <?php isset($options['opt2Colour']) ? selected( $options['opt2Colour'], 'green' ) : '' ?>>Green</option>
							<option value='navy' <?php isset($options['opt2Colour']) ? selected( $options['opt2Colour'], 'navy' ) : '' ?>>Navy</option>
							<option value='blue' <?php isset($options['opt2Colour']) ? selected( $options['opt2Colour'], 'blue' ) : '' ?>>Blue</option>
							<option value='yellow' <?php isset($options['opt2Colour']) ? selected( $options['opt2Colour'], 'yellow' ) : '' ?>>Yellow</option>
							<option value='white' <?php isset($options['opt2Colour']) ? selected( $options['opt2Colour'], 'white' ) : '' ?>>White</option>
							<option value='black' <?php isset($options['opt2Colour']) ? selected( $options['opt2Colour'], 'black' ) : '' ?>>Black</option>
							<option value='transparent' <?php isset($options['opt2Colour']) ? selected( $options['opt2Colour'], 'transparent' ) : '' ?>>Transparent</option>								
						</select>
					</td>
				</tr>
				<tr valign="top"><th scope="row">Option 3 colour</th>
					<td>
						<select id="ddbs5_theme_options[opt3Colour]" name='ddbs5_theme_options[opt3Colour]'>
							<option selected value>Choose...</option>
							<option value='purple' <?php isset($options['opt3Colour']) ? selected( $options['opt3Colour'], 'purple' ) : '' ?>>Purple</option>
							<option value='teal' <?php isset($options['opt3Colour']) ? selected( $options['opt3Colour'], 'teal' ) : '' ?>>Teal</option>
							<option value='red' <?php isset($options['opt3Colour']) ? selected( $options['opt3Colour'], 'red' ) : '' ?>>Red</option>
							<option value='pink' <?php isset($options['opt3Colour']) ? selected( $options['opt3Colour'], 'pink' ) : '' ?>>Pink</option>
							<option value='green' <?php isset($options['opt3Colour']) ? selected( $options['opt3Colour'], 'green' ) : '' ?>>Green</option>
							<option value='navy' <?php isset($options['opt3Colour']) ? selected( $options['opt3Colour'], 'navy' ) : '' ?>>Navy</option>
							<option value='blue' <?php isset($options['opt3Colour']) ? selected( $options['opt3Colour'], 'blue' ) : '' ?>>Blue</option>
							<option value='yellow' <?php isset($options['opt3Colour']) ? selected( $options['opt3Colour'], 'yellow' ) : '' ?>>Yellow</option>
							<option value='white' <?php isset($options['opt3Colour']) ? selected( $options['opt3Colour'], 'white' ) : '' ?>>White</option>
							<option value='black' <?php isset($options['opt3Colour']) ? selected( $options['opt3Colour'], 'black' ) : '' ?>>Black</option>
							<option value='transparent' <?php isset($options['opt3Colour']) ? selected( $options['opt3Colour'], 'transparent' ) : '' ?>>Transparent</option>								
						</select>
					</td>
				</tr>								
			</table>

			<p class="submit">
				<input type="submit" class="button-primary" value="<?php _e( 'Save Options', 'ddbs5-theme' ); ?>" />
			</p>
		</form>
	</div>
	<?php

}
