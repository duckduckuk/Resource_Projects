var story = 0
var outline = ""
function gener8story(story){
if (story === 1){
var time1 = prompt("Morning or afternoon?:")
var talktype1 = prompt("Site Induction or Toolbox Talk?:")
var leader1 = prompt("Supervisor or Site Manager?:")
var topic1 = prompt("Topic:")
var otherworks1 = prompt("Other site vehicle/opearative:")
var city1 = prompt("Location:")
var coinFlip = Math.floor((Math.random() * 2) + 1)
var prediction = ""
if (coinFlip === 1){
  prediction = "player hater."
}
else{
  prediction = "player themselves."
}
outline = "I arrived at the "+city1+" site in the "+time1+" and parked in the staff carpark. I then signed in at the site entrance using my site pass and followed the segrgated walkway to the lockers in the welfare block. I applied my PPE (hard hat, glasses, hi-vis top/trousers, safety boots and gloves) and made my way over to attend a briefing where the "+leader1+" gave a "+talktype1+" focusing on "+topic1+" and the site in general and any of the day’s activities that had been planned. We were told that "+otherworks1+" would be using the site road today as there was "+topic1+" taking place. "+prediction
}
  else if (story === 2){
    var adj1 = prompt("Adjective:")
    var noun3 = prompt("Noun:")
    var pnoun1 = prompt("Plural noun:")
    var adj2 = prompt("Adjective:")
    var adj3 = prompt("Adjective:")
    var verbing1 = prompt("Verb ending in \'ing\':")
    var verbing2 = prompt("Verb ending in \'ing\':")
    var adj4 = prompt("Adjective:")
    var adj5 = prompt("Adjective:")
    var bp1 = prompt("Part of Body:")
    var bpp1 = prompt("Part of Body (plural):")
    var adj6 = prompt("Adjective:")
    var food1 = prompt("Food (plural):")
    var car1 = prompt("Vehicle:")
    var food2 = prompt("Food (plural):")
    var food3 = prompt("Food (plural):")
    var athing1 = prompt("Something Alive (plural):")
    var athing2 = prompt("Somehting Alive (plural):")
    var adv1 = prompt("Adverb:")
    var noun4 = prompt("Noun:")
    outline = "If you go to some "+adj1+" place like Yellowstone National "+noun3+", you must know how to defend yourself from wild animals like bears and wolves and "+pnoun1+". The most important of those is the bear. There are 3 kinds of bear. The grizzly bear, the "+adj2+" bear, and the "+adj3+" bear. Bears spend most of their time "+verbing1+" or "+verbing2+". They look very "+adj4+", but if you make them "+adj5+", they might bite your "+bp1+". Bears will come up to your car and beg for "+food1+" They will stand on their hind legs and clap their "+bpp1+" and pretend to be "+adj6+". But do not get out of your "+car1+" or offer the bears "+food2+" or "+food3+". The same advice applies to other wild creatures such as "+athing1+" and "+athing2+". Remember all these rules and you will spend your vacation "+adv1+" and not get eaten alive by a "+noun4+"."
  }
  else if(story === 3) {
    var adjectt = prompt("Adjective: ")
    var adjecti = prompt("Adjective: ")
    var gname1 = prompt("Girl's Name: ")
    var nouncers = prompt("Noun: ")
    var adject2 = prompt("Another Adjective: ")
    var nounb = prompt("Noun: ")
    outline = "Once upon a time, there was a /an "+adjectt+" merchant. He had a beautiful wife, and a/an "+adjecti+" daughter named "+gname1+". One day, the merchant's wife fell ill and, soon afterwards, died. The merchant remarried, to a woman who was ugly. This ugly woman also had two "+nouncers+" who were very ugly, too. The merchant left on a business trip, leaving his daughter with his new wife. "+gname1+"'s stepmother treated her as a slave, and the daughters "
    }
  
document.getElementById("outline"+story).innerHTML = outline;  
  }