#!/usr/bin/env sh

#POLYBAR
#Terminate Existing Instances
killall -q i3bar
killall -q polybar
#Launch Polybar
polybar one
