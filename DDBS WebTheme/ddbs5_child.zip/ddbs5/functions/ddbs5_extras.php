<?php

class WP_Widget_ddbs5_Speechbubble extends WP_Widget {

	/**
	 * Sets up a new ddbs5 Speechbubble widget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'WP_Widget_ddbs5_Speechbubble',
			'description' => __( 'Add a ddbs5 Speechbubble to the sidebar.' ),
			'customize_selective_refresh' => true,
		);
		$control_ops = array( 'width' => 400, 'height' => 350 );
		parent::__construct( 'ddbs5_speechbubble', __( 'ddbs5 Speechbubble' ), $widget_ops, $control_ops );
	}

	/**
	 * Outputs the content for the current ddbs5 Speechbubble widget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current ddbs5 Speechbubble widget instance.
	 */
	public function widget( $args, $instance ) {
		
		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */

		$widget_text = ! empty( $instance['speechbubble_text'] ) ? $instance['speechbubble_text'] : '';

		/**
		 * Filters the content of the ddbs5 Speechbubble widget.
		 *
		 * @since 2.3.0
		 * @since 4.4.0 Added the `$this` parameter.
		 *
		 * @param string         $widget_text The widget content.
		 * @param array          $instance    Array of settings for the current widget.
		 * @param WP_Widget_ddbs5_Speechbubble $this        Current ddbs5 Speechbubble widget instance.
		 */
		$text = apply_filters( 'widget_text', $widget_text, $instance, $this );
		
		echo $args['before_widget'];?>

		<div class="speechbubble">

				<div class="speechbubble-body">
				
			<div class="speechbubble-text"><p class="bubble speech"><?php echo !empty( $instance['filter'] ) ? wpautop( $text ) : $text; ?></p></div>
				</div>
		</div>
		<?php
		echo $args['after_widget'];
	}

	/**
	 * Handles updating settings for the current ddbs5 Speechbubble widget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Settings to save or bool false to cancel saving.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = sanitize_text_field( $new_instance['title'] );
		if ( current_user_can( 'unfiltered_html' ) ) {
			$instance['speechbubble_text'] = $new_instance['speechbubble_text'];
		} else {
			$instance['speechbubble_text'] = wp_kses_post( $new_instance['speechbubble_text'] );
		}
		$instance['filter'] = ! empty( $new_instance['filter'] );
		return $instance;
	}

	/**
	 * Outputs the ddbs5 Speechbubble widget settings form.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'speechbubble_text' => '' ) );
		$filter = isset( $instance['filter'] ) ? $instance['filter'] : 0;
		$title = sanitize_text_field( $instance['title'] );

		?>

		<p><label for="<?php echo $this->get_field_id( 'speechbubble_text' ); ?>"><?php _e( 'Content:' ); ?></label>
		<textarea class="widefat" rows="11" cols="20" id="<?php echo $this->get_field_id('speechbubble_text'); ?>" name="<?php echo $this->get_field_name('speechbubble_text'); ?>"><?php echo esc_textarea( $instance['speechbubble_text'] ); ?></textarea></p>

		<p><input id="<?php echo $this->get_field_id('filter'); ?>" name="<?php echo $this->get_field_name('filter'); ?>" type="checkbox"<?php checked( $filter ); ?> />&nbsp;<label for="<?php echo $this->get_field_id('filter'); ?>"><?php _e('Automatically add paragraphs'); ?></label></p>
		<?php
	}
}


// Register Widget
function register_WP_Widget_ddbs5_Speechbubble() {
    register_widget( 'WP_Widget_ddbs5_Speechbubble' );
}

add_action( 'widgets_init', 'register_WP_Widget_ddbs5_Speechbubble' );
// ////////////////////
// THOUGHT BUBBLE START
// ////////////////////
class WP_Widget_ddbs5_Thoughtbubble extends WP_Widget {

	/**
	 * Sets up a new ddbs5 Thoughtbubble widget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'WP_Widget_ddbs5_Thoughtbubble',
			'description' => __( 'Add a ddbs5 Thoughtbubble to the sidebar.' ),
			'customize_selective_refresh' => true,
		);
		$control_ops = array( 'width' => 400, 'height' => 350 );
		parent::__construct( 'ddbs5_thoughtbubble', __( 'ddbs5 Thoughtbubble' ), $widget_ops, $control_ops );
	}

	/**
	 * Outputs the content for the current ddbs5 Thoughtbubble widget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current ddbs5 Thoughtbubble widget instance.
	 */
	public function widget( $args, $instance ) {
		
		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */

		$widget_text = ! empty( $instance['thoughtbubble_text'] ) ? $instance['thoughtbubble_text'] : '';

		/**
		 * Filters the content of the ddbs5 Thoughtbubble widget.
		 *
		 * @since 2.3.0
		 * @since 4.4.0 Added the `$this` parameter.
		 *
		 * @param string         $widget_text The widget content.
		 * @param array          $instance    Array of settings for the current widget.
		 * @param WP_Widget_ddbs5_Thoughtbubble $this        Current ddbs5 Thoughtbubble widget instance.
		 */
		$text = apply_filters( 'widget_text', $widget_text, $instance, $this );
		
		echo $args['before_widget'];?>

		<div class="thoughtbubble">

				<div class="thoughtbubble-body">
				
			<div class="thoughtbubble-text"><p class="bubble thought"><?php echo !empty( $instance['filter'] ) ? wpautop( $text ) : $text; ?></p></div>
				</div>
		</div>
		<?php
		echo $args['after_widget'];
	}

	/**
	 * Handles updating settings for the current ddbs5 Thoughtbubble widget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Settings to save or bool false to cancel saving.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = sanitize_text_field( $new_instance['title'] );
		if ( current_user_can( 'unfiltered_html' ) ) {
			$instance['thoughtbubble_text'] = $new_instance['thoughtbubble_text'];
		} else {
			$instance['thoughtbubble_text'] = wp_kses_post( $new_instance['thoughtbubble_text'] );
		}
		$instance['filter'] = ! empty( $new_instance['filter'] );
		return $instance;
	}

	/**
	 * Outputs the ddbs5 Thoughtbubble widget settings form.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'thoughtbubble_text' => '' ) );
		$filter = isset( $instance['filter'] ) ? $instance['filter'] : 0;
		$title = sanitize_text_field( $instance['title'] );

		?>

		<p><label for="<?php echo $this->get_field_id( 'thoughtbubble_text' ); ?>"><?php _e( 'Content:' ); ?></label>
		<textarea class="widefat" rows="11" cols="20" id="<?php echo $this->get_field_id('thoughtbubble_text'); ?>" name="<?php echo $this->get_field_name('thoughtbubble_text'); ?>"><?php echo esc_textarea( $instance['thoughtbubble_text'] ); ?></textarea></p>

		<p><input id="<?php echo $this->get_field_id('filter'); ?>" name="<?php echo $this->get_field_name('filter'); ?>" type="checkbox"<?php checked( $filter ); ?> />&nbsp;<label for="<?php echo $this->get_field_id('filter'); ?>"><?php _e('Automatically add paragraphs'); ?></label></p>
		<?php
	}
}


// Register Widget
function register_WP_Widget_ddbs5_Thoughtbubble() {
    register_widget( 'WP_Widget_ddbs5_Thoughtbubble' );
}

add_action( 'widgets_init', 'register_WP_Widget_ddbs5_Thoughtbubble' );

// ////////////////
// ddbs5 CARD WIDGET
// ////////////////
class WP_Widget_ddbs5_Card extends WP_Widget {

	/**
	 * Sets up a new ddbs5 Card widget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'wp_widget_ddbs5_card',
			'description' => __( 'Add a ddbs5 Card to the sidebar.' ),
			'customize_selective_refresh' => true,
		);
		$control_ops = array( 'width' => 400, 'height' => 350 );
		parent::__construct( 'ddbs5_card', __( 'ddbs5 Card' ), $widget_ops, $control_ops );
	}

	/**
	 * Outputs the content for the current ddbs5 Card widget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current ddbs5 Card widget instance.
	 */
	public function widget( $args, $instance ) {
		
		$card_img = ! empty( $instance['card-img'] ) ? $instance['card-img'] : '';

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		$widget_text = ! empty( $instance['ddbs5-card-text'] ) ? $instance['ddbs5-card-text'] : '';

		$card_link = ! empty( $instance['card-link'] ) ? $instance['card-link'] : '';
		$card_link_title = ! empty( $instance['card-link-title'] ) ? $instance['card-link-title'] : '';


		/**
		 * Filters the content of the ddbs5 Card widget.
		 *
		 * @since 2.3.0
		 * @since 4.4.0 Added the `$this` parameter.
		 *
		 * @param string         $widget_text The widget content.
		 * @param array          $instance    Array of settings for the current widget.
		 * @param WP_Widget_ddbs5_Card $this        Current ddbs5 Card widget instance.
		 */
		$text = apply_filters( 'widget_text', $widget_text, $instance, $this );
		$img = apply_filters( 'card_img', $card_img, $instance, $this ); 	

        $link = apply_filters( 'card_link', $card_link, $instance, $this );
		$link_title = apply_filters( 'card_link_title', $card_link_title, $instance, $this );
		
		echo $args['before_widget'];?>

		<div class="card">
			<?php if ( ! empty( $card_img ) ) { ?>
			<img class="card-img-top img-fluid h-100" src="<?php echo !empty( $instance['filter'] ) ? wpautop( $img ) : $img; ?>" alt="">
			<?php } ?>
				<div class="card-body">
				
		<?php if ( ! empty( $title ) ) {
			echo '<div class="card-title">' . $args['before_title'] . $title . $args['after_title'] . '</div>';
		} ?>
			<div class="card-text"><?php echo !empty( $instance['filter'] ) ? wpautop( $text ) : $text; ?></div>

                <?php if ( ! empty( $link_title ) ) { ?>	
				<hr>	
			<a class="btn btn-primary btn-lg" role="button" href="<?php echo !empty( $instance['filter'] ) ? wpautop( $link ) : $link; ?>">
				<?php echo !empty( $instance['filter'] ) ? wpautop( $link_title ) : $link_title; ?>
			</a>
		<?php } ?> 					
					
				</div>
		</div>
		<?php
		echo $args['after_widget'];
	}

	/**
	 * Handles updating settings for the current ddbs5 Card widget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Settings to save or bool false to cancel saving.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = sanitize_text_field( $new_instance['title'] );
		if ( current_user_can( 'unfiltered_html' ) ) {
			$instance['ddbs5-card-text'] = $new_instance['ddbs5-card-text'];
            $instance['card-img'] = $new_instance['card-img'];
			$instance['card-link'] = $new_instance['card-link'];
			$instance['card-link-title'] = $new_instance['card-link-title'];            
		} else {
			$instance['ddbs5-card-text'] = wp_kses_post( $new_instance['ddbs5-card-text'] );
            $instance['card-img'] = wp_kses_post( $new_instance['card-img'] );
			$instance['card-link'] = wp_kses_post( $new_instance['card-link'] );
			$instance['card-link-title'] = wp_kses_post( $new_instance['card-link-title'] );            
		}
		$instance['filter'] = ! empty( $new_instance['filter'] );
		return $instance;
	}

	/**
	 * Outputs the ddbs5 Card widget settings form.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'ddbs5-card-text' => '' ) );
		$instance = wp_parse_args( (array) $instance, array( 'card_img' => '', 'card-img' => '' ) );
		$instance = wp_parse_args( (array) $instance, array( 'card_link' => '', 'card-link' => '' ) );
		$instance = wp_parse_args( (array) $instance, array( 'card_link_title' => '', 'card-link-title' => '' ) );
        $filter = isset( $instance['filter'] ) ? $instance['filter'] : 0;
		$title = sanitize_text_field( $instance['title'] );

		?>
		<p><label for="<?php echo $this->get_field_id('card-img'); ?>"><?php _e('Image URL:'); ?></label>
		<textarea class="widefat" rows="2" cols="20" id="<?php echo $this->get_field_id('card-img'); ?>" name="<?php echo $this->get_field_name('card-img'); ?>"><?php echo esc_textarea( $instance['card-img'] ); ?></textarea>
		<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		<p><label for="<?php echo $this->get_field_id( 'ddbs5-card-text' ); ?>"><?php _e( 'Content:' ); ?></label>
		<textarea class="widefat" rows="11" cols="20" id="<?php echo $this->get_field_id('ddbs5-card-text'); ?>" name="<?php echo $this->get_field_name('ddbs5-card-text'); ?>"><?php echo esc_textarea( $instance['ddbs5-card-text'] ); ?></textarea></p>

		<p><label for="<?php echo $this->get_field_id('card-link-title'); ?>"><?php _e('Button Name:'); ?></label>
		<textarea class="widefat" rows="2" cols="20" id="<?php echo $this->get_field_id('card-link-title'); ?>" name="<?php echo $this->get_field_name('card-link-title'); ?>"><?php echo esc_textarea( $instance['card-link-title'] ); ?></textarea>
		
		<p><label for="<?php echo $this->get_field_id('card-link'); ?>"><?php _e('Button URL:'); ?></label>
		<textarea class="widefat" rows="2" cols="20" id="<?php echo $this->get_field_id('card-link'); ?>" name="<?php echo $this->get_field_name('card-link'); ?>"><?php echo esc_textarea( $instance['card-link'] ); ?></textarea>

		<p><input id="<?php echo $this->get_field_id('filter'); ?>" name="<?php echo $this->get_field_name('filter'); ?>" type="checkbox"<?php checked( $filter ); ?> />&nbsp;<label for="<?php echo $this->get_field_id('filter'); ?>"><?php _e('Automatically add paragraphs'); ?></label></p>
		<?php
	}
}


// Register Widget
function register_wp_widget_ddbs5_card() {
    register_widget( 'WP_Widget_ddbs5_Card' );
}

add_action( 'widgets_init', 'register_wp_widget_ddbs5_card' );
// ////////////////
// JUMBOTRON WIDGET
// ////////////////

class WP_Widget_ddbs5_Jumbotron extends WP_Widget {

	public function __construct() {
		$widget_ops = array(
			'classname' => 'wp_widget_ddbs5_jumbotron',
			'description' => __( 'Add a ddbs5 Jumbotron to widget areas.' ),
			'customize_selective_refresh' => true,
		);
		$control_ops = array( 'width' => 400, 'height' => 350 );
		parent::__construct( 'ddbs5_jumbotron', __( 'ddbs5 Jumbotron' ), $widget_ops, $control_ops );
	}

	public function widget( $args, $instance ) {

		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
		$widget_text = ! empty( $instance['ddbs5-jumbotron-text'] ) ? $instance['ddbs5-jumbotron-text'] : '';
		$jumbotron_img = ! empty( $instance['jumbotron-img'] ) ? $instance['jumbotron-img'] : '';		
		$jumbotron_link = ! empty( $instance['jumbotron-link'] ) ? $instance['jumbotron-link'] : '';
		$jumbotron_link_title = ! empty( $instance['jumbotron-link-title'] ) ? $instance['jumbotron-link-title'] : '';

		$text = apply_filters( 'widget_text', $widget_text, $instance, $this );
		$img = apply_filters( 'jumbotron_img', $jumbotron_img, $instance, $this ); 	
		$link = apply_filters( 'jumbotron_link', $jumbotron_link, $instance, $this );
		$link_title = apply_filters( 'jumbotron_link_title', $jumbotron_link_title, $instance, $this );
		
		echo $args['before_widget'];?>

		<div class="jumbotron mt-4 mb-5" <?php if ( ! empty( $jumbotron_img ) ) { ?> style='background:url("<?php echo !empty( $instance['filter'] ) ? wpautop( $img ) : $img; ?>") no-repeat center center;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover' <?php } ?>>
				
		<?php if ( ! empty( $title ) ) {
			echo $args['before_title'] . $title . $args['after_title'];
		} ?>
			<p><?php echo !empty( $instance['filter'] ) ? wpautop( $text ) : $text; ?></p>
		
		<?php if ( ! empty( $link_title ) ) { ?>	
			<a class="btn btn-primary btn-lg" role="button" href="<?php echo !empty( $instance['filter'] ) ? wpautop( $link ) : $link; ?>">
				<?php echo !empty( $instance['filter'] ) ? wpautop( $link_title ) : $link_title; ?>
			</a>
		<?php } ?>
		
		</div>
		<?php
		echo $args['after_widget'];
	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = sanitize_text_field( $new_instance['title'] );
		if ( current_user_can( 'unfiltered_html' ) ) {
			$instance['ddbs5-jumbotron-text'] = $new_instance['ddbs5-jumbotron-text'];
			$instance['jumbotron-img'] = $new_instance['jumbotron-img'];
			$instance['jumbotron-link'] = $new_instance['jumbotron-link'];
			$instance['jumbotron-link-title'] = $new_instance['jumbotron-link-title'];
		} else {
			$instance['ddbs5-jumbotron-text'] = wp_kses_post( $new_instance['ddbs5-jumbotron-text'] );
			$instance['jumbotron-img'] = wp_kses_post( $new_instance['jumbotron-img'] );
			$instance['jumbotron-link'] = wp_kses_post( $new_instance['jumbotron-link'] );
			$instance['jumbotron-link-title'] = wp_kses_post( $new_instance['jumbotron-link-title'] );
		}
		$instance['filter'] = ! empty( $new_instance['filter'] );
		return $instance;
	}

	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'ddbs5-jumbotron-text' => '' ) );
		$instance = wp_parse_args( (array) $instance, array( 'jumbotron_img' => '', 'jumbotron-img' => '' ) );
		$instance = wp_parse_args( (array) $instance, array( 'jumbotron_link' => '', 'jumbotron-link' => '' ) );
		$instance = wp_parse_args( (array) $instance, array( 'jumbotron_link_title' => '', 'jumbotron-link-title' => '' ) );
		$filter = isset( $instance['filter'] ) ? $instance['filter'] : 0;
		$title = sanitize_text_field( $instance['title'] );

		?>
		<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		<p><label for="<?php echo $this->get_field_id( 'ddbs5-jumbotron-text' ); ?>"><?php _e( 'Content:' ); ?></label>
		<textarea class="widefat" rows="11" cols="20" id="<?php echo $this->get_field_id('ddbs5-jumbotron-text'); ?>" name="<?php echo $this->get_field_name('ddbs5-jumbotron-text'); ?>"><?php echo esc_textarea( $instance['ddbs5-jumbotron-text'] ); ?></textarea></p>
		
		<p><label for="<?php echo $this->get_field_id('jumbotron-link-title'); ?>"><?php _e('Button Name:'); ?></label>
		<textarea class="widefat" rows="2" cols="20" id="<?php echo $this->get_field_id('jumbotron-link-title'); ?>" name="<?php echo $this->get_field_name('jumbotron-link-title'); ?>"><?php echo esc_textarea( $instance['jumbotron-link-title'] ); ?></textarea>
		
		<p><label for="<?php echo $this->get_field_id('jumbotron-link'); ?>"><?php _e('Button URL:'); ?></label>
		<textarea class="widefat" rows="2" cols="20" id="<?php echo $this->get_field_id('jumbotron-link'); ?>" name="<?php echo $this->get_field_name('jumbotron-link'); ?>"><?php echo esc_textarea( $instance['jumbotron-link'] ); ?></textarea>
		
		<p><label for="<?php echo $this->get_field_id('jumbotron-img'); ?>"><?php _e('Background Image URL:'); ?></label>
		<textarea class="widefat" rows="2" cols="20" id="<?php echo $this->get_field_id('jumbotron-img'); ?>" name="<?php echo $this->get_field_name('jumbotron-img'); ?>"><?php echo esc_textarea( $instance['jumbotron-img'] ); ?></textarea>

		<p><input id="<?php echo $this->get_field_id('filter'); ?>" name="<?php echo $this->get_field_name('filter'); ?>" type="checkbox"<?php checked( $filter ); ?> />&nbsp;<label for="<?php echo $this->get_field_id('filter'); ?>"><?php _e('Automatically add paragraphs'); ?></label></p>
		<?php
	}
}


// Register Widget
function register_wp_widget_ddbs5_jumbotron() {
    register_widget( 'WP_Widget_ddbs5_Jumbotron' );
}

add_action( 'widgets_init', 'register_wp_widget_ddbs5_jumbotron' );
