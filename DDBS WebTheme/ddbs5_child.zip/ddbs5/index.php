<?php
	get_header();
	b4st_main_before();
?>
	<?php ddbs5_subheader();?>
<main id="site-main" class="container">
	<div class="row">

	</div>

	<?php /* if ((isset($options['sidebar']) ? $options['sidebar'] : false)) {
		get_sidebar();
	}
	*/ ?>

	</div><!-- /.row -->
</main><!-- /.container -->
	<?php ddbs5_prefooter();?>
<?php
	b4st_main_after();
	get_footer();
?>
