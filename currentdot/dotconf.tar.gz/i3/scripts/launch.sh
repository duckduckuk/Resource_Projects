#!/usr/bin/env sh

# #---Bar---# #

#Terminate Existing Instances
killall -q [name here]

#Launch or relaunch instance

