#!/usr/bin/env sh

#POLYBAR
#Terminate Existing Instances
killall -q i3bar
killall -q polybar

#TINT
killall -q tint2


# Wait until the processes have been shut down
while pgrep -u $UID -x polybar >/dev/null; do sleep 1; done

#Launch Polybar
polybar one
