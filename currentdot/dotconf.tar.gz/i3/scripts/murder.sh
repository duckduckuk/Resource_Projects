#!/usr/bin/env sh

# #---Bar---# #

#Terminate Existing Instances
killall -q [name here]
killall -q conky


