<?php
/*
 * Widgets
 */

function b4st_widgets_init() {

  /*
  Sidebar (one widget area)
   */
  register_sidebar( array(
    'name'            => __( 'Sidebar', 'b4st' ),
    'id'              => 'sidebar-widget-area',
    'description'     => __( 'The sidebar widget area', 'b4st' ),
    'before_widget'   => '<section class="%1$s rounded p-3 mb-2 %2$s">', /* ITEMS REMOVED (ADD TO CLASS TO RESTORE) : bg-white shadow-sm*/
    'after_widget'    => '</section>',
    'before_title'    => '<h2 class="h4">',
    'after_title'     => '</h2>',
  ) );

  /*
  Footer (1, 2, 3, or 4 areas)

  Flexbox `col-sm` gives the correct the column width:

  * If only 1 widget, then this will have full width ...
  * If 2 widgets, then these will each have half width ...
  * If 3 widgets, then these will each have third width ...
  * If 4 widgets, then these will each have quarter width ...
  ... above the Bootstrap `sm` breakpoint.
  */

  register_sidebar( array(
    'name'            => __( 'Footer', 'b4st' ),
    'id'              => 'footer-widget-area',
    'description'     => __( 'The footer widget area', 'b4st' ),
    'before_widget'   => '<div class="%1$s bg-white rounded p-3 mb-2 shadow-sm %2$s col-sm">',
    'after_widget'    => '</div>',
    'before_title'    => '<h2 class="h4">',
    'after_title'     => '</h2>',
  ) );

}
add_action( 'widgets_init', 'b4st_widgets_init' );

/* PREPAGE START */

register_sidebar( array(
  'name'            => __( 'Pre Page Masthead', 'ddbs5' ),
  'id'              => 'ddbs5_prepage',
  'description'     => __( 'Use 1, 2, 3 or 4 widgets.', 'ddbs' ),
  'before_widget'   => '<div class="%1$s %2$s col-sm">',
  'after_widget'    => '</div>',
  'before_title'    => '<h2 class="h4">',
  'after_title'     => '</h2>',
) );	

function ddbs5_prepage() {
  if ( is_active_sidebar( 'ddbs5_prepage' ) ) {
    ?>
<?php $options = get_option('ddbs5_theme_options');
 	  $brand_colour = get_text_light_dark($options['opt1Colour']); 
    $text_colour = get_text_light_dark($options['opt1Colour']);
?>
<div id="ddbs5_prepage" class="ddbs5_prepage pt-2 pb-2 text-white>">
			<div class="container">
			<?php dynamic_sidebar( 'ddbs5_prepage' ); ?>
			</div>	
		</div>
    <?php
  } else {
		//
	}
}

/* PREPAGE END */

/* PREHEADER START */

register_sidebar( array(
  'name'            => __( 'Preheader', 'ddbs5' ),
  'id'              => 'ddbs5_preheader',
  'description'     => __( 'Use 1, 2, 3 or 4 widgets.', 'ddbs' ),
  'before_widget'   => '<div class="">',
  'after_widget'    => '</div>',
  'before_title'    => '<h2 class="h4">',
  'after_title'     => '</h2>',
) );	

function ddbs5_preheader() {
  if ( is_active_sidebar( 'ddbs5_preheader' ) ) {
    ?>
<?php $options = get_option('ddbs5_theme_options');
 	  $brand_colour = get_text_light_dark($options['opt1Colour']); 
	  $text_colour = get_text_light_dark($options['opt1Colour']);
?>
<div id="ddbs5_preheader" class="ddbs_preheader navbar-<?php echo get_reverse_light_dark($brand_colour) ?> bg-ddbs5-<?php echo (!empty($options['opt1Colour']) ? $options['opt1Colour'] : 'purple') ?> text-<?php echo $text_colour ?> shadow-sm">
			<div class="">
			<?php dynamic_sidebar( 'ddbs5_preheader' ); ?>
			</div>	
		</div>
    <?php
  } else {
		//
	}
}

/* PREHEADER END */

/* SUBHEADER START */

   register_sidebar( array(
    'name'            => __( 'Frontpage Subheader', 'ddbs5' ),
    'id'              => 'ddbs5_subheader',
    'description'     => __( 'Use 1, 2, 3 or 4 widgets.', 'ddbs' ),
    'before_widget'   => '<div class="%1$s %2$s col-sm">',
    'after_widget'    => '</div>',
    'before_title'    => '<h2 class="h4">',
    'after_title'     => '</h2>',
  ) );	
	
function ddbs5_subheader() {
  if ( is_active_sidebar( 'ddbs5_subheader' ) ) {
    ?>
<?php $options = get_option('ddbs5_theme_options');
 	  $brand_colour = get_text_light_dark($options['opt2Colour']); 
	  $text_colour = get_text_light_dark($options['opt2Colour']);
?>
<div id="site-main-widgets" class="ddbs5_subheader site-main-widgets main-widget-area Navbar-<?php echo get_reverse_light_dark($brand_colour) ?> bg-ddbs5-<?php echo (!empty($options['opt2Colour']) ? $options['opt2Colour'] : 'purple') ?> text-<?php echo $text_colour ?>">
		<div class="">
		  <div class="row" id="" role="">	
		<?php dynamic_sidebar( 'ddbs5_subheader' ); ?>	
		  </div>  
		</div>
	</div>
    <?php
  } else {
		//
	}
}

/* SUBHEADER END */

/* PREFOOTER START */

register_sidebar( array(
  'name'            => __( 'Frontpage Prefooter', 'ddbs5' ),
  'id'              => 'ddbs5_prefooter',
  'description'     => __( 'Use 1, 2, 3 or 4 widgets.', 'ddbs' ),
  'before_widget'   => '<div class="%1$s %2$s col-sm">',
  'after_widget'    => '</div>',
  'before_title'    => '<h2 class="h4">',
  'after_title'     => '</h2>',
) );	

function ddbs5_prefooter() {
if ( is_active_sidebar( 'ddbs5_prefooter' ) ) {
  ?>
<?php $options = get_option('ddbs5_theme_options');
   $brand_colour = get_text_light_dark($options['opt2Colour']); 
  $text_colour = get_text_light_dark($options['opt2Colour']);
?>
<div id="site-main-widgets" class="ddbs5_prefooter site-main-widgets mb-0 main-widget-area Navbar-<?php echo get_reverse_light_dark($brand_colour) ?> bg-ddbs5-<?php echo (!empty($options['opt2Colour']) ? $options['opt2Colour'] : 'purple') ?> text-<?php echo $text_colour ?>">
  <div class="container pt-5 pb-4">
    <div class="row" id="" role="">	
  <?php dynamic_sidebar( 'ddbs5_prefooter' ); ?>	
    </div>  
  </div>
</div>
  <?php
} else {
  //
}
}

/* PREFOOTER END */