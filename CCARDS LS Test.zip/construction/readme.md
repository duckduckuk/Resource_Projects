V1.4
====

Encryption is just a test. All code in this project is subject to MIT
