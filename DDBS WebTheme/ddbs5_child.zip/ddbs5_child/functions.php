<?php 
/* Enqueue Theme Sheet */
function ddbs5_child_enqueues() { 
  /* Enqueue your own styles in here */ 	
  wp_enqueue_style( 'ddbs5_child', get_stylesheet_directory_uri() . '/css/ddbs5-child.css', false, null); 
  wp_enqueue_style( 'ddbs5_child_extra', get_stylesheet_directory_uri() . '/css/ddbs5-child-extra.css', false, null); 
  /* Enqueue your own scripts in here */ 
} add_action('wp_enqueue_scripts', 'ddbs5_child_enqueues', 101); 
/* End Enqueue Theme Sheet */

/* Navbar on/off
function remove_navbar_search() {  
	?><button type="button" class="btn btn-success">Contact us</button>
	<?php
}
add_action( 'navbar_search', 'remove_navbar_search' ); 
/* End Navbar on/off */
?>
